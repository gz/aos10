/* NSLU2 control program
   Uses the DTR line on an FTDI USB-serial converter to control the 
   reset line on the NSLU2 
   Written for the UNSW AOS course, 2006 by David Snowdon
   Cleaned up a tad in 2008 by Andrew Baumann
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int serial_port_fd;

#define DTR_PULSE     2
#define DTR_UP        1
#define DTR_DOWN      0

/* Below partly borrowed from GTKterm */ 
int
set_signal(unsigned int param)
{
	int stat_;
	
	if(serial_port_fd == -1)
		return -1;
	
	if(ioctl(serial_port_fd, TIOCMGET, &stat_) == -1) {
		if (errno == EFAULT) {
			/* Linux's ftdi_sio driver before 2.6.24ish doesn't implement this :(
			 * ... so just make something up! :) -AB 20080220 */
			stat_ = 0;
		} else {
			perror("TIOCMGET ioctl");
			return -1;
		}
	}
	
	if(param == DTR_PULSE){
		stat_ ^= TIOCM_DTR;
		if(ioctl(serial_port_fd, TIOCMSET, &stat_) == -1) {
			perror("TIOCMSET ioctl");
			return -1;
		}
		
		usleep(500000); 
		
		stat_ ^= TIOCM_DTR; 
		if(ioctl(serial_port_fd, TIOCMSET, &stat_) == -1) {
			perror("TIOCMSET ioctl");
			return -1;
		}
	}else{
		/* Command is not DTR_PULSE */ 
		if(param == DTR_UP)
			stat_ &= ~TIOCM_DTR;
		else
			stat_ |= TIOCM_DTR;
		
		if(ioctl(serial_port_fd, TIOCMSET, &stat_) == -1) {
			perror("TIOCMSET ioctl");
			return -1;
		}
	}

	return 0;
}

int
open_port(char *port)
{
	serial_port_fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
	if(serial_port_fd == -1){
		fprintf(stderr, "nslu2: error opening serial port\n"); 
		perror("open"); 
		return -1;
	}

	return 0;
}

int
main(int argc, char** argv)
{
	char defport[] = "/dev/ttyUSB0";
	char* port; 
	int i, param = -1;
	
	port = defport; 
	
	for(i=1; i<argc; i++){
		if(strcasecmp("-p", argv[i]) == 0 && i + 1 < argc){
			i++;
			port = argv[i];
		}else if(strcmp("up", argv[i]) == 0){
			param = DTR_UP;
		}else if(strcmp("down", argv[i]) == 0){
			param = DTR_DOWN;
		}else if(strcmp("reset", argv[i]) == 0){
			param = DTR_PULSE;
		}else{
			goto usage;
		}
	}


	if (param == -1) {
		goto usage;
	}

	if (open_port(port) != 0)
		return 1;
	if (set_signal(param) != 0)
		return 1;
	return 0;

usage:
	printf("Usage: nslu2 <-p port> up|down|reset\n"); 
	return 1;
}
