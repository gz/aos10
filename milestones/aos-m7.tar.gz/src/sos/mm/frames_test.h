#ifndef _FRAMES_TEST_H
#define _FRAMES_TEST_H

/* Some test functions to ensure functionality of the frame table */
void frame_test1(void);
void frame_test2(void);
void frame_test3(void);
void frame_test4(void);


#endif // _FRAMES_TEST_H
