/*
 * sos_serial.h
 *
 */

#ifndef SOS_SERIAL_H_
#define SOS_SERIAL_H_
/*

#define MSG_WORD_SIZE (sizeof(L4_Word_t))
#define MSG_MAX_REGISTERS 4
#define MSG_MAX_SIZE ((MSG_MAX_REGISTERS) * (MSG_WORD_SIZE))

extern void sos_serial_send(L4_Msg_t*, int*);

//extern void network_irq    (L4_ThreadId_t *tP, int *sendP);

*/

#endif /* SOS_SERIAL_H_ */
